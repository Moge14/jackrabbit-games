---
name: Example Game
description: A short, snappy one-liner shown on the game card. Keep it under 100 characters.
tags: action, puzzle
version: 1.0
date: 2025-01-01
emoji: 🎯
play_url: https://moge14.github.io/gamehub-moge14/example-game
windows_file: game-windows.exe
mac_file: game-mac.zip
---

This is the full description shown when a player clicks the game card.
You can write as many paragraphs as you like here — markdown is supported in spirit,
but it renders as plain text in the modal.

Describe what the game is about, how to play, any tips, or anything else you want
players to know before they dive in.

HOW TO ADD YOUR OWN GAME
─────────────────────────
1. Duplicate this folder inside /games/  →  games/my-cool-game/
2. Edit README.md with your game's details (the --- block at the top is required).
3. (Optional) Add a 16:9 thumbnail image named thumbnail.png or thumbnail.jpg.
4. (Optional) Add download files:
     games/my-cool-game/game-windows.exe
     games/my-cool-game/game-mac.zip
5. Commit & push to GitHub — the site will pick it up automatically!

TIP: The folder name becomes the game's slug.  Spaces → hyphens, all lowercase.
     e.g. "Space Dash" → games/space-dash/
